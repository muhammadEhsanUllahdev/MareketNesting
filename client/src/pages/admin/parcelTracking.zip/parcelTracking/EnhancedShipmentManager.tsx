import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Package,
  Truck,
  MapPin,
  Clock,
  Plus,
  Search,
  Filter,
  Eye,
  Edit,
  CheckCircle,
  AlertTriangle,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

// Données de démonstration pour les expéditions
const mockShipments = [
  {
    id: "EXP-2024-001",
    orderId: "CMD-1234",
    customerName: "Ahmed Benali",
    customerPhone: "0555123456",
    origin: "Alger",
    destination: "Oran",
    carrier: "Yalidine",
    status: "en_transit",
    trackingNumber: "YAL123456789",
    estimatedDelivery: "2024-12-28",
    actualDelivery: null,
    weight: "2.5 kg",
    value: "15000 DA",
    shippingCost: "800 DA",
    notes: "Livraison en main propre uniquement",
    createdAt: "2024-12-25T10:00:00Z",
  },
  {
    id: "EXP-2024-002",
    orderId: "CMD-1235",
    customerName: "Fatima Ouali",
    customerPhone: "0666987654",
    origin: "Constantine",
    destination: "Annaba",
    carrier: "Zoom Delivery",
    status: "livre",
    trackingNumber: "ZOM987654321",
    estimatedDelivery: "2024-12-26",
    actualDelivery: "2024-12-26T14:30:00Z",
    weight: "1.2 kg",
    value: "8500 DA",
    shippingCost: "600 DA",
    notes: "",
    createdAt: "2024-12-24T08:30:00Z",
  },
  {
    id: "EXP-2024-003",
    orderId: "CMD-1236",
    customerName: "Karim Mansouri",
    customerPhone: "0777456123",
    origin: "Alger",
    destination: "Tlemcen",
    carrier: "Yalidine",
    status: "en_preparation",
    trackingNumber: "YAL456789123",
    estimatedDelivery: "2024-12-30",
    actualDelivery: null,
    weight: "3.8 kg",
    value: "22000 DA",
    shippingCost: "1000 DA",
    notes: "Produit fragile - Manipulation avec précaution",
    createdAt: "2024-12-25T16:45:00Z",
  },
  {
    id: "EXP-2024-004",
    orderId: "CMD-1237",
    customerName: "Sarah Amrani",
    customerPhone: "0550321789",
    origin: "Oran",
    destination: "Setif",
    carrier: "Express DZ",
    status: "retarde",
    trackingNumber: "EXP321789456",
    estimatedDelivery: "2024-12-27",
    actualDelivery: null,
    weight: "0.8 kg",
    value: "5500 DA",
    shippingCost: "450 DA",
    notes: "Retard dû aux conditions météorologiques",
    createdAt: "2024-12-23T12:15:00Z",
  },
];

const EnhancedShipmentManager = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  type Shipment = (typeof mockShipments)[number];
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(
    null
  );
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [shipments, setShipments] = useState(mockShipments);

  const filteredShipments = shipments.filter((shipment) => {
    const matchesSearch =
      shipment.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      shipment.trackingNumber
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      shipment.orderId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || shipment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "en_preparation":
        return (
          <Badge className="bg-blue-100 text-blue-800">En préparation</Badge>
        );
      case "en_transit":
        return (
          <Badge className="bg-orange-100 text-orange-800">En transit</Badge>
        );
      case "livre":
        return <Badge className="bg-green-100 text-green-800">Livré</Badge>;
      case "retarde":
        return <Badge className="bg-red-100 text-red-800">Retardé</Badge>;
      default:
        return <Badge variant="outline">Inconnu</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "en_preparation":
        return <Package className="h-4 w-4 text-blue-600" />;
      case "en_transit":
        return <Truck className="h-4 w-4 text-orange-600" />;
      case "livre":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "retarde":
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  const handleViewDetails = (shipment: any) => {
    setSelectedShipment(shipment);
    setIsDetailsModalOpen(true);
  };

  const handleEditShipment = (shipment?: any) => {
    if (shipment) {
      setSelectedShipment(shipment);
      setIsDetailsModalOpen(true);
    } else {
      setIsDetailsModalOpen(false);
    }
  };

  const handleUpdateStatus = () => {
    if (!selectedShipment) return;

    const nextStatus = getNextStatus(selectedShipment.status);

    // Mettre à jour les expéditions
    const updatedShipments = shipments.map((shipment) =>
      shipment.id === selectedShipment.id
        ? { ...shipment, status: nextStatus }
        : shipment
    );

    setShipments(updatedShipments);
    setSelectedShipment({ ...selectedShipment, status: nextStatus });

    alert(`Statut mis à jour vers: ${getStatusLabel(nextStatus)}`);
  };

  const handleUpdateShipmentStatus = (shipment: any) => {
    if (!shipment || shipment.status === "livre") return;

    const nextStatus = getNextStatus(shipment.status);

    // Mettre à jour les expéditions
    const updatedShipments = shipments.map((s) =>
      s.id === shipment.id ? { ...s, status: nextStatus } : s
    );

    setShipments(updatedShipments);
    alert(
      `Statut de l'expédition ${shipment.id} mis à jour vers: ${getStatusLabel(
        nextStatus
      )}`
    );
  };

  const handleCreateNewShipment = () => {
    // Créer une nouvelle expédition avec des données par défaut
    const newShipment = {
      id: `EXP-2024-${String(shipments.length + 1).padStart(3, "0")}`,
      orderId: `CMD-${Math.floor(Math.random() * 9999)}`,
      customerName: "Nouveau Client",
      customerPhone: "0555000000",
      origin: "Alger",
      destination: "Oran",
      carrier: "Yalidine",
      status: "en_preparation",
      trackingNumber: `TRK${Math.floor(Math.random() * 999999999)}`,
      estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0],
      actualDelivery: null,
      weight: "1 kg",
      value: "10000 DA",
      shippingCost: "500 DA",
      notes: "",
      createdAt: new Date().toISOString(),
    };

    setShipments([...shipments, newShipment]);
    setIsCreateModalOpen(false);
    alert("Nouvelle expédition créée avec succès !");
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "en_preparation":
        return "En préparation";
      case "en_transit":
        return "En transit";
      case "livre":
        return "Livré";
      case "retarde":
        return "Retardé";
      default:
        return "Inconnu";
    }
  };

  const getNextStatus = (currentStatus: string) => {
    const statusFlow = {
      en_preparation: "en_transit",
      en_transit: "livre",
      livre: "livre",
      retarde: "en_transit",
    };
    return (
      statusFlow[currentStatus as keyof typeof statusFlow] || currentStatus
    );
  };

  const handleCreateShipment = () => {
    setIsCreateModalOpen(true);
  };

  const CreateShipmentModal = () => (
    <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Créer une nouvelle expédition</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Numéro de commande</label>
              <Input placeholder="CMD-xxxx" />
            </div>
            <div>
              <label className="text-sm font-medium">Client</label>
              <Input placeholder="Nom du client" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Téléphone</label>
              <Input placeholder="0555123456" />
            </div>
            <div>
              <label className="text-sm font-medium">Transporteur</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Choisir un transporteur" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yalidine">Yalidine</SelectItem>
                  <SelectItem value="zoom">Zoom Delivery</SelectItem>
                  <SelectItem value="express">Express DZ</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Origine</label>
              <Input placeholder="Ville d'origine" />
            </div>
            <div>
              <label className="text-sm font-medium">Destination</label>
              <Input placeholder="Ville de destination" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium">Poids</label>
              <Input placeholder="2.5 kg" />
            </div>
            <div>
              <label className="text-sm font-medium">Valeur</label>
              <Input placeholder="15000 DA" />
            </div>
            <div>
              <label className="text-sm font-medium">Coût livraison</label>
              <Input placeholder="800 DA" />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Notes</label>
            <Textarea placeholder="Instructions spéciales..." />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => setIsCreateModalOpen(false)}
            >
              Annuler
            </Button>
            <Button onClick={handleCreateNewShipment}>
              Créer l'expédition
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );

  const ShipmentDetailsModal = () => (
    <Dialog open={isDetailsModalOpen} onOpenChange={setIsDetailsModalOpen}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            Détails de l'expédition {selectedShipment?.id}
          </DialogTitle>
        </DialogHeader>
        {selectedShipment && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              {getStatusIcon(selectedShipment.status)}
              {getStatusBadge(selectedShipment.status)}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Commande
                </label>
                <p className="font-medium">{selectedShipment.orderId}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Numéro de suivi
                </label>
                <p className="font-medium">{selectedShipment.trackingNumber}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Client
                </label>
                <p className="font-medium">{selectedShipment.customerName}</p>
                <p className="text-sm text-muted-foreground">
                  {selectedShipment.customerPhone}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Transporteur
                </label>
                <p className="font-medium">{selectedShipment.carrier}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Origine
                </label>
                <p className="font-medium">{selectedShipment.origin}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Destination
                </label>
                <p className="font-medium">{selectedShipment.destination}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Poids
                </label>
                <p className="font-medium">{selectedShipment.weight}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Valeur
                </label>
                <p className="font-medium">{selectedShipment.value}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Coût livraison
                </label>
                <p className="font-medium">{selectedShipment.shippingCost}</p>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-muted-foreground">
                Livraison estimée
              </label>
              <p className="font-medium">
                {new Date(
                  selectedShipment.estimatedDelivery
                ).toLocaleDateString("fr-FR")}
              </p>
            </div>

            {selectedShipment.notes && (
              <div>
                <label className="text-sm font-medium text-muted-foreground">
                  Notes
                </label>
                <p className="font-medium">{selectedShipment.notes}</p>
              </div>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={handleEditShipment}>
                <Edit className="h-4 w-4 mr-1" />
                Modifier
              </Button>
              <Button onClick={handleUpdateStatus}>Mettre à jour statut</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestion des Expéditions</h2>
          <p className="text-muted-foreground">
            Créez et suivez toutes les expéditions
          </p>
        </div>
        <Button
          onClick={handleCreateShipment}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Nouvelle expédition
        </Button>
      </div>

      {/* Statistiques */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5 text-blue-600" />
              Total
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockShipments.length}</div>
            <p className="text-sm text-muted-foreground">Expéditions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Truck className="h-5 w-5 text-orange-600" />
              En transit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mockShipments.filter((s) => s.status === "en_transit").length}
            </div>
            <p className="text-sm text-muted-foreground">Actives</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Livrées
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mockShipments.filter((s) => s.status === "livre").length}
            </div>
            <p className="text-sm text-muted-foreground">Complétées</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              Retardées
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mockShipments.filter((s) => s.status === "retarde").length}
            </div>
            <p className="text-sm text-muted-foreground">Problèmes</p>
          </CardContent>
        </Card>
      </div>

      {/* Tableau des expéditions */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Liste des Expéditions</CardTitle>
            <p className="text-sm text-muted-foreground">
              Toutes les expéditions en cours et terminées
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher..."
                className="pl-8 w-[250px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous</SelectItem>
                <SelectItem value="en_preparation">En préparation</SelectItem>
                <SelectItem value="en_transit">En transit</SelectItem>
                <SelectItem value="livre">Livré</SelectItem>
                <SelectItem value="retarde">Retardé</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Expédition</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Itinéraire</TableHead>
                  <TableHead>Transporteur</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Livraison prévue</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredShipments.map((shipment) => (
                  <TableRow key={shipment.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{shipment.id}</div>
                        <div className="text-sm text-muted-foreground">
                          {shipment.orderId}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {shipment.customerName}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {shipment.customerPhone}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        <span className="text-sm">
                          {shipment.origin} → {shipment.destination}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Truck className="h-4 w-4 text-blue-600" />
                        {shipment.carrier}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(shipment.status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(
                          shipment.estimatedDelivery
                        ).toLocaleDateString("fr-FR")}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {/* Bouton Voir détails */}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleViewDetails(shipment)}
                          className="h-8 w-8 p-0 hover:bg-blue-50 transition-colors"
                          title="Voir les détails"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>

                        {/* Bouton Modifier */}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditShipment(shipment)}
                          className="h-8 w-8 p-0 hover:bg-green-50 transition-colors"
                          title="Modifier l'expédition"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>

                        {/* Bouton Mettre à jour le statut */}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleUpdateShipmentStatus(shipment)}
                          className="h-8 w-8 p-0 hover:bg-orange-50 transition-colors"
                          disabled={shipment.status === "livre"}
                          title={
                            shipment.status === "livre"
                              ? "Expédition déjà livrée"
                              : "Mettre à jour le statut"
                          }
                        >
                          {getStatusIcon(shipment.status)}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <CreateShipmentModal />
      <ShipmentDetailsModal />
    </div>
  );
};

export default EnhancedShipmentManager;
