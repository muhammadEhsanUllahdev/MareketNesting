
import React from 'react';
import { FileBarChart, TrendingUp, Bell, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

interface ShipmentsHeaderProps {
  onDownloadReport: () => void;
  onShareReport: () => void;
  alertsCount?: number;
}

export const ShipmentsHeader: React.FC<ShipmentsHeaderProps> = ({
  onDownloadReport,
  onShareReport,
  alertsCount = 0
}) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
      <div>
        <h1 className="text-2xl font-bold">Suivi des Expéditions</h1>
        <p className="text-muted-foreground">Gestion centralisée des expéditions multi-transporteurs</p>
      </div>
      
      <div className="flex flex-wrap gap-2">
        {alertsCount > 0 && (
          <Button variant="destructive" className="gap-1">
            <Bell className="h-4 w-4" />
            Alertes
            <Badge className="ml-1 bg-white text-red-500 hover:bg-gray-100">{alertsCount}</Badge>
          </Button>
        )}
        <Button variant="outline" onClick={onDownloadReport}>
          <FileBarChart className="mr-2 h-4 w-4" />
          Exporter les données
        </Button>
        <Button className="bg-primary" onClick={onShareReport}>
          <TrendingUp className="mr-2 h-4 w-4" />
          Rapport de performance
        </Button>
      </div>
    </div>
  );
};

export default ShipmentsHeader;
