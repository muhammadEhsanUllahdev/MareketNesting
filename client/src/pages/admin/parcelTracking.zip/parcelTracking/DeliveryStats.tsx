import React from "react";
import { Package, Truck, CalendarClock, AlertTriangle } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

interface DeliveryStatsProps {
  shipments: any;
  isLoading: boolean;
}
interface Shipment {
  status?: string;
  estimated_delivery?: string;
}

interface DeliveryStatsResult {
  total: number;
  inTransit: number;
  delivered: number;
  delayed: number;
  returned: number;
  todayDeliveries: number;
}

export const DeliveryStats: React.FC<DeliveryStatsProps> = ({
  shipments,
  isLoading,
}) => {
  // Fonction pour calculer les statistiques de livraison
  const getDeliveryStats = () => {
    if (isLoading || !shipments)
      return {
        total: 0,
        inTransit: 0,
        delivered: 0,
        delayed: 0,
        returned: 0,
        todayDeliveries: 0,
      };

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const shipmentsTyped: Shipment[] = shipments as Shipment[];

    return {
      total: shipmentsTyped.length,
      inTransit: shipmentsTyped.filter(
        (s) =>
          s.status?.toLowerCase() === "in_transit" ||
          s.status?.toLowerCase() === "en transit"
      ).length,
      delivered: shipmentsTyped.filter(
        (s) =>
          s.status?.toLowerCase() === "delivered" ||
          s.status?.toLowerCase() === "livré"
      ).length,
      delayed: shipmentsTyped.filter(
        (s) =>
          s.status?.toLowerCase() === "delayed" ||
          s.status?.toLowerCase() === "retardé"
      ).length,
      returned: shipmentsTyped.filter(
        (s) =>
          s.status?.toLowerCase() === "returned" ||
          s.status?.toLowerCase() === "retourné"
      ).length,
      todayDeliveries: shipmentsTyped.filter((s) => {
        if (!s.estimated_delivery) return false;
        const deliveryDate = new Date(s.estimated_delivery);
        deliveryDate.setHours(0, 0, 0, 0);
        return deliveryDate.getTime() === today.getTime();
      }).length,
    } as DeliveryStatsResult;
  };

  // Obtenir les statistiques
  const stats = getDeliveryStats();

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="overflow-hidden">
        <CardHeader className="pb-2 bg-primary/5">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Total des expéditions
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="p-2 bg-primary/10 rounded-full">
              <Package className="h-5 w-5 text-primary" />
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            {stats.delivered} livraisons complétées
          </p>
        </CardContent>
      </Card>

      <Card className="overflow-hidden">
        <CardHeader className="pb-2 bg-blue-50">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            En transit
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold">{stats.inTransit}</div>
            <div className="p-2 bg-blue-100 rounded-full">
              <Truck className="h-5 w-5 text-blue-500" />
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            {Math.round((stats.inTransit / (stats.total || 1)) * 100)}% des
            expéditions
          </p>
        </CardContent>
      </Card>

      <Card className="overflow-hidden">
        <CardHeader className="pb-2 bg-green-50">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Livraisons du jour
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold">{stats.todayDeliveries}</div>
            <div className="p-2 bg-green-100 rounded-full">
              <CalendarClock className="h-5 w-5 text-green-500" />
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Prévues pour aujourd'hui
          </p>
        </CardContent>
      </Card>

      <Card className="overflow-hidden">
        <CardHeader className="pb-2 bg-red-50">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Livraisons en retard
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold">{stats.delayed}</div>
            <div className="p-2 bg-red-100 rounded-full">
              <AlertTriangle className="h-5 w-5 text-red-500" />
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            {stats.returned} retours signalés
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default DeliveryStats;
