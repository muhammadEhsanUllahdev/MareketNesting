import React, { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import { Package, Truck, Map, TrendingUp, AlertTriangle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useShipments } from "@/pages/seller/shipping/hooks/useShipments";
import { useCarriers } from "@/pages/seller/shipping/hooks/carriers";
import { useToast } from "@/hooks/use-toast";

// Importing our refactored components
import EnhancedShipmentManager from "./EnhancedShipmentManager";
import DeliveryStats from "./DeliveryStats";
import CarrierPerformance from "./CarrierPerformance";
import ShipmentsAnalytics from "./ShipmentsAnalytics";
import ShipmentsMap from "./ShipmentsMap";
import ShipmentsHeader from "./ShipmentsHeader";

const ShipmentsPage = () => {
  const { shipments, isLoading } = useShipments();
  const { carriers } = useCarriers();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("tracking");
  const [alertsCount, setAlertsCount] = useState(0);

  // Calculate alerts count (delayed or problematic shipments)
  useEffect(() => {
    if (shipments) {
      const delayed = shipments.filter(
        (shipment) =>
          shipment.status === "delayed" ||
          shipment.status === "retardé" ||
          (shipment.estimated_delivery &&
            new Date(shipment.estimated_delivery) < new Date())
      );
      setAlertsCount(delayed.length);
    }
  }, [shipments]);

  const handleDownloadReport = () => {
    toast({
      title: "Rapport exporté",
      description: "Le rapport d'expédition a été téléchargé avec succès",
    });
  };

  const handleShareReport = () => {
    toast({
      title: "Rapport partagé",
      description: "Le rapport d'expédition a été partagé par email",
    });
  };

  return (
    <DashboardLayout title="Gestion des expéditions">
      <div className="space-y-6">
        <ShipmentsHeader
          onDownloadReport={handleDownloadReport}
          onShareReport={handleShareReport}
          alertsCount={alertsCount}
        />

        <DeliveryStats shipments={shipments} isLoading={isLoading} />

        <Tabs
          defaultValue="tracking"
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid grid-cols-3 mb-6 w-full max-w-md">
            <TabsTrigger value="tracking" className="flex items-center gap-1">
              <Package className="h-4 w-4" />
              <span className="hidden sm:inline mr-1">Suivi</span>
              des colis
            </TabsTrigger>
            <TabsTrigger
              value="performance"
              className="flex items-center gap-1"
            >
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline mr-1">Analyse</span>
              performance
            </TabsTrigger>
            <TabsTrigger value="maps" className="flex items-center gap-1">
              <Map className="h-4 w-4" />
              <span className="hidden sm:inline">Cartographie</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="tracking" className="space-y-6">
            <EnhancedShipmentManager />
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <CarrierPerformance carriers={carriers} shipments={shipments} />
            <ShipmentsAnalytics />
          </TabsContent>

          <TabsContent value="maps" className="space-y-6">
            <ShipmentsMap />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

export default ShipmentsPage;
